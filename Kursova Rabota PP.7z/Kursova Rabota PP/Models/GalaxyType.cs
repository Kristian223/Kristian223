﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kursova_Rabota_PP.Models
{
    public enum GalaxyType
    {
        Elliptical,
        Lenticular,
        Spiral,
        Irregular
    }
}
